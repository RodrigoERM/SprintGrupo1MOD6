package cl.Grupo1.M6Sprint.model.service;

import cl.Grupo1.M6Sprint.model.entity.Capacitacion;
import cl.Grupo1.M6Sprint.model.entity.Usuarios;
import cl.Grupo1.M6Sprint.model.repository.ICapacitacionRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CapacitacionService {

    private static final Logger logger = Logger.getLogger(CapacitacionService.class);

	// Inyectar el repositorio JPA
    @Autowired
    private ICapacitacionRepository capacitacionRepository;

    // Método para obtener todas las capacitaciones
    public List<Capacitacion> findAll() {
        logger.info("Obteniendo lista de capacitaciones desde la base de datos.");
        return capacitacionRepository.findAll(); // Llamar al método del repositorio
    }
    
	public Capacitacion getOne(int id) {		
		return capacitacionRepository.findById(id).get();
	}

    // Método para crear una nueva capacitación
    public Capacitacion save(Capacitacion capacitacion) {
        logger.info("Creando nueva capacitación: ID: " + capacitacion.getId() + 
                    ", Nombre: " + capacitacion.getNombreCapacitacion() + 
                    ", Detalle: " + capacitacion.getDetalle());

       return capacitacionRepository.save(capacitacion); // Guardar la capacitación utilizando JPA
    }
    
 // Método para actualizar una capacitacion existente
    public Capacitacion update(Capacitacion CapacitacionActualizada) {
        // Buscar la capacitacion por su ID en la base de datos
    	Capacitacion capacitacionExistente = capacitacionRepository.findById(CapacitacionActualizada.getId())
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado con ID: " + CapacitacionActualizada.getId()));
        // Actualizar los campos de la capacitacion existente con los valores de la capacitacion actualizada
    	capacitacionExistente.setNombreCapacitacion(CapacitacionActualizada.getNombreCapacitacion());
    	capacitacionExistente.setDetalle(CapacitacionActualizada.getDetalle());
    	capacitacionExistente.setValor(CapacitacionActualizada.getValor());
        
        // Guardar la capacitacion actualizada en la base de datos
        return capacitacionRepository.save(capacitacionExistente);
}
}
