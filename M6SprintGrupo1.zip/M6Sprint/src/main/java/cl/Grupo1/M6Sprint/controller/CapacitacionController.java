package cl.Grupo1.M6Sprint.controller;

import cl.Grupo1.M6Sprint.model.entity.Capacitacion;
import cl.Grupo1.M6Sprint.model.service.CapacitacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import java.util.Arrays;
import java.util.List;

@Controller
public class CapacitacionController {

    @Autowired
    private CapacitacionService capacitacionService; // Inyectar el servicio
   
    @RequestMapping(path = "/crearcapacitacion", method = RequestMethod.GET)
    public ModelAndView mostrarCrearCapacitacion() {
        return new ModelAndView("crearcapacitacion");
    }

    @RequestMapping(path = "/listarcapacitacion", method = RequestMethod.GET)
    public ModelAndView mostrarListarCapacitacion() {
        List<Capacitacion> capacitaciones = capacitacionService.findAll(); // Llamar al método del servicio
        ModelAndView mav = new ModelAndView("listarcapacitacion");
        mav.addObject("capacitaciones", capacitaciones);
        return mav;
    }
    
    @RequestMapping(path = "/crearcapacitacion", method = RequestMethod.POST)
    public ModelAndView procesarCrearCapacitacion(Capacitacion capacitacion) {
        // Llamar al método del servicio para agregar la capacitación
        capacitacionService.save(capacitacion);
        // Redirigir a la lista de capacitaciones
        return new ModelAndView("redirect:/listarcapacitacion");
    }
    
    // Método para mostrar el formulario de edición de un usuario existente
    @GetMapping("/editarcapacitacion/{id}")
    public String mostrarEditarCapacitacion(@PathVariable("id") int id, Model model) {
        Capacitacion capacitacion = capacitacionService.getOne(id);
        model.addAttribute("capacitacion", capacitacion);
        return "editarcapacitacion";
    }

    // Método para procesar la edición de un usuario
    @PostMapping("/editarcapacitacion")
    public String procesarEditarCapacitacion(Capacitacion capacitacion) {
        // Llamar al servicio para actualizar el usuario
    	capacitacionService.update(capacitacion);
        return "redirect:/listarcapacitacion";
    }
}
