package cl.Grupo1.M6Sprint.model.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import cl.Grupo1.M6Sprint.model.entity.Pago;

public interface IPagoRepository extends JpaRepository<Pago, Integer> {
	}