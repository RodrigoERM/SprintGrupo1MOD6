package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "profesional")
public class Profesional {

	
    @Id
    @Column(name = "id")
    private int id;

    @Column(name="años_experiencia")
    private int añosExperiencia;
    
    @Column(name="departamento")
    private String departamento;

	public Profesional() {
		super();
	}

	public Profesional(int id, int añosExperiencia, String departamento) {
		super();
		this.id = id;
		this.añosExperiencia = añosExperiencia;
		this.departamento = departamento;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAñosExperiencia() {
		return añosExperiencia;
	}

	public void setAñosExperiencia(int añosExperiencia) {
		this.añosExperiencia = añosExperiencia;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
 
    
    
}
