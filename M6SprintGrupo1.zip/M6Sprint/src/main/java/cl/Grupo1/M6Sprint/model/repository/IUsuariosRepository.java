package cl.Grupo1.M6Sprint.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.Grupo1.M6Sprint.model.entity.Usuarios;

/**
 * Repositorio para la entidad Usuarios.
 * 
 * Proporciona métodos para realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar)
 * en la tabla "usuarios" de la base de datos.
 * 
 * Extiende JpaRepository para heredar una variedad de métodos predefinidos, como save(), findAll(), findById(), delete(), etc.
 * 
 * @see org.springframework.data.jpa.repository.JpaRepository
 */
public interface IUsuariosRepository extends JpaRepository<Usuarios, Integer>  {

}
