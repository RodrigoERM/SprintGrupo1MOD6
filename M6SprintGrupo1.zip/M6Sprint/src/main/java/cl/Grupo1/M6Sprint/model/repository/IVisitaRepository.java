package cl.Grupo1.M6Sprint.model.repository;

import cl.Grupo1.M6Sprint.model.entity.Visitas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IVisitaRepository extends JpaRepository<Visitas, Integer> {
}
