package cl.Grupo1.M6Sprint.controller;

import cl.Grupo1.M6Sprint.model.service.UsuariosService;
import cl.Grupo1.M6Sprint.model.entity.Usuarios;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

/**
 * Controlador para gestionar las operaciones relacionadas con los usuarios.
 * Maneja las solicitudes HTTP para listar, crear y procesar la creación de usuarios.
 */
@Controller
public class UsuariosController {

    private static final Logger logger = Logger.getLogger(UsuariosController.class);

    @Autowired
    private UsuariosService usuariosService;

    // Método para listar los usuarios
    @GetMapping("/listarusuarios")
    public String listarUsuarios(Model model) {
        List<Usuarios> usuarios = usuariosService.findAll();
        model.addAttribute("usuarios", usuarios);
        return "listarusuarios";
    }

    // Método para mostrar el formulario de crear usuario
    @GetMapping("/crearusuario")
    public String mostrarCrearUsuario(Model model) {
        model.addAttribute("usuario", new Usuarios());
        return "crearusuario";
    }

    // Método para procesar la creación de un nuevo usuario
    @PostMapping("/crearusuario")
    public String procesarCrearUsuario(Usuarios usuario) {
        logger.info("Creando nuevo usuario: Tipo de Usuario: " + usuario.getTipoUsuario() +
                    ", Nombre: " + usuario.getNombre() + 
                    ", Correo: " + usuario.getCorreo());
        usuariosService.save(usuario);
        return "redirect:/listarusuarios";
    }

    // Método para mostrar el formulario de edición de un usuario existente
    @GetMapping("/editarusuario/{id}")
    public String mostrarEditarUsuario(@PathVariable("id") int id, Model model) {
        Usuarios usuario = usuariosService.getOne(id);
        model.addAttribute("usuario", usuario);
        return "editarusuario";
    }

    // Método para procesar la edición de un usuario
    @PostMapping("/editarusuario")
    public String procesarEditarUsuario(Usuarios usuario) {
        logger.info("Editando usuario: ID: " + usuario.getId() + 
                    ", Nombre: " + usuario.getNombre() + 
                    ", Correo: " + usuario.getCorreo());

        // Llamar al servicio para actualizar el usuario
        usuariosService.update(usuario);
        return "redirect:/listarusuarios";
    }
}