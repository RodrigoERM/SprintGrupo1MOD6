package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Pago")
public class Pago {
	
    @Id
    @Column(name = "id")
    private int id;
    
    @Column(name = "monto_cobro")
    private int montoCobro;
    
    @Column(name="monto_pagado")
    private int montoPagado;
    
    @Column(name="fecha_pago")
    private String fechaPago;
    
    @Column(name="estado")
    private String estado;

	public Pago() {
		super();
	}

	public Pago(int id, int montoCobro, int montoPagado, String fechaPago, String estado) {
		super();
		this.id = id;
		this.montoCobro = montoCobro;
		this.montoPagado = montoPagado;
		this.fechaPago = fechaPago;
		this.estado = estado;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMontoCobro() {
		return montoCobro;
	}

	public void setMontoCobro(int montoCobro) {
		this.montoCobro = montoCobro;
	}

	public int getMontoPagado() {
		return montoPagado;
	}

	public void setMontoPagado(int montoPagado) {
		this.montoPagado = montoPagado;
	}

	public String getFechaPago() {
		return fechaPago;
	}

	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
    
    
}
