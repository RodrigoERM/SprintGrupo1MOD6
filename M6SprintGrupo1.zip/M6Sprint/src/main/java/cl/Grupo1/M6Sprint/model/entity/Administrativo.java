package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "administrativo")
public class Administrativo {

    @Id
    @Column(name = "id")
    private int id;

    @Column(name="funcion")
    private int funcion;
    
    @Column(name="nombre_superior")
    private String nombreSuperior;

	public Administrativo() {
		super();
	}

	public Administrativo(int id, int funcion, String nombreSuperior) {
		super();
		this.id = id;
		this.funcion = funcion;
		this.nombreSuperior = nombreSuperior;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFuncion() {
		return funcion;
	}

	public void setFuncion(int funcion) {
		this.funcion = funcion;
	}

	public String getNombreSuperior() {
		return nombreSuperior;
	}

	public void setNombreSuperior(String nombreSuperior) {
		this.nombreSuperior = nombreSuperior;
	}
    
    
    
}
