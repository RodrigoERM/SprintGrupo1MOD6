package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capacitaciones")
public class Capacitacion {

    @Id
    @Column(name="id")
    private int id;
    
    @Column(name="nombre")
    private String nombreCapacitacion;
    
    @Column(name="detalle")
    private String detalle;
    
    @Column(name="valor")
    private String valor;
    
    
	public Capacitacion() {
		super();
	}


	public Capacitacion(int id, String nombreCapacitacion, String detalle, String valor) {
		super();
		this.id = id;
		this.nombreCapacitacion = nombreCapacitacion;
		this.detalle = detalle;
		this.valor = valor;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNombreCapacitacion() {
		return nombreCapacitacion;
	}


	public void setNombreCapacitacion(String nombreCapacitacion) {
		this.nombreCapacitacion = nombreCapacitacion;
	}


	public String getDetalle() {
		return detalle;
	}


	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}


	public String getValor() {
		return valor;
	}


	public void setValor(String valor) {
		this.valor = valor;
	}


}
