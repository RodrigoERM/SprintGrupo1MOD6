package cl.Grupo1.M6Sprint.model.service;

import org.springframework.stereotype.Service;
import cl.Grupo1.M6Sprint.model.entity.Cliente;
import cl.Grupo1.M6Sprint.model.repository.IClienteRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClienteService {

    private final IClienteRepository clienteRepository;

    // Constructor
    public ClienteService(IClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    // Método para obtener clientes
    public List<Cliente> obtenerClientes() {
        return clienteRepository.findAll().stream()
            .map(cliente -> new Cliente(cliente.getId(), cliente.getNombreCliente(), cliente.getRut()))
            .collect(Collectors.toList());
    }
}
