package cl.Grupo1.M6Sprint.controller;

import cl.Grupo1.M6Sprint.model.entity.Pago;
import cl.Grupo1.M6Sprint.model.entity.Cliente;
import cl.Grupo1.M6Sprint.model.service.PagoService;
import cl.Grupo1.M6Sprint.model.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import java.time.LocalDate;
import java.util.List;
import java.time.format.DateTimeFormatter;

@Controller
public class PagoController {

    @Autowired
    private PagoService pagoService;
    
    @Autowired
    private ClienteService clienteService;

    // Listado de pagos
    @GetMapping("/listarPagos")
    public String listarPagos(Model model) {
        List<Pago> pagos = pagoService.getAllPagos();
        model.addAttribute("pagos", pagos);
        return "listarPago"; // JSP que mostrará el listado de pagos
    }

    // Formulario para crear un nuevo pago
    @GetMapping("/crearPago")
    public String mostrarFormularioPago(Model model) {
        model.addAttribute("pago", new Pago());
        List<Cliente> clientes = clienteService.obtenerClientes();
        model.addAttribute("clientes", clientes); // Para seleccionar el cliente
        return "crearPago"; // JSP para crear el pago
    }

    // Procesar el pago
    @PostMapping("/crearPago")
    public String crearPago(@ModelAttribute("pago") Pago pago, Model model) {
        if (pago.getMontoPagado() == pago.getMontoCobro()) {
            pago.setEstado("Pagado");
            
            // Convertir LocalDate a String con el formato adecuado
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String fechaPagoStr = LocalDate.now().format(formatter);
            
            pago.setFechaPago(fechaPagoStr); // Guardar la fecha como String
            pagoService.createPago(pago);
            return "redirect:/listarPagos"; // Redirigir al listado de pagos
        } else {
            model.addAttribute("error", "El monto pagado debe ser igual al monto del cobro.");
            List<Cliente> clientes = clienteService.obtenerClientes();
            model.addAttribute("clientes", clientes); // Para seleccionar el cliente nuevamente
            return "listarPagos"; // Retornar al formulario si hay error
        }
    }
}
