package cl.Grupo1.M6Sprint.model.service;

import cl.Grupo1.M6Sprint.model.entity.Usuarios;
import cl.Grupo1.M6Sprint.model.repository.IUsuariosRepository;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuariosService {

    private static final Logger logger = Logger.getLogger(UsuariosService.class);

    
    public UsuariosService() {
		super();
	}

	// Inyectar el repositorio JPA
    @Autowired
    private IUsuariosRepository usuariosRepository;

    // Método para obtener todos los usuarios
    public List<Usuarios> findAll() {
        logger.info("Obteniendo lista de usuarios desde la base de datos.");
        return usuariosRepository.findAll(); // Llamar al método del repositorio
    }

	public Usuarios getOne(int id) {		
		return usuariosRepository.findById(id).get();
	}
	
    // Método para crear un nuevo usuario
    public Usuarios save(Usuarios usuario) {
        logger.info("Creando nuevo usuario: ID: " + usuario.getId() + 
                    ", Nombre: " + usuario.getNombre() + 
                    ", Correo: " + usuario.getCorreo() + 
                    ", Tipo de Usuario: " + usuario.getTipoUsuario());
        
        return usuariosRepository.save(usuario); // Guardar el usuario utilizando JPA
    }
    
 // Método para actualizar un usuario existente
    public Usuarios update(Usuarios usuarioActualizado) {
        // Buscar el usuario por su ID en la base de datos
        Usuarios usuarioExistente = usuariosRepository.findById(usuarioActualizado.getId())
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado con ID: " + usuarioActualizado.getId()));
        // Actualizar los campos del usuario existente con los valores del usuario actualizado
        usuarioExistente.setNombre(usuarioActualizado.getNombre());
        usuarioExistente.setCorreo(usuarioActualizado.getCorreo());
        usuarioExistente.setTipoUsuario(usuarioActualizado.getTipoUsuario());
        
        // Guardar el usuario actualizado en la base de datos
        return usuariosRepository.save(usuarioExistente);
}
}
