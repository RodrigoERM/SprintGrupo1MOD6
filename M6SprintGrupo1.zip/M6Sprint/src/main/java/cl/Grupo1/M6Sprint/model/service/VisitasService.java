package cl.Grupo1.M6Sprint.model.service;

import cl.Grupo1.M6Sprint.model.entity.Visitas;
import cl.Grupo1.M6Sprint.model.repository.IVisitaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
/**
 * Servicio para la gestión de las visitas en el sistema.
 * 
 * Proporciona métodos para crear, obtener, y eliminar visitas utilizando el repositorio {@link IVisitaRepository}.
 */
@Service
public class VisitasService {

    @Autowired
    private IVisitaRepository visitaRepository;

    // Crear una nueva visita
    public Visitas createVisita(Visitas visitas) {
        return visitaRepository.save(visitas);
    }

    // Obtener todas las visitas
    public List<Visitas> getAllVisitas() {
        return visitaRepository.findAll();
    }

    // Obtener una visita por su ID
    public Optional<Visitas> getVisitaById(int id) {
        return visitaRepository.findById(id);
    }

    // Eliminar una visita
    public void deleteVisita(int id) {
        visitaRepository.deleteById(id);
    }
}
