package cl.Grupo1.M6Sprint.model.service;

import cl.Grupo1.M6Sprint.model.entity.Pago;
import cl.Grupo1.M6Sprint.model.repository.IPagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PagoService {

    @Autowired
    private IPagoRepository pagoRepository;

    // Crear un nuevo pago
    public Pago createPago(Pago pago) {
        return pagoRepository.save(pago);
    }

    // Obtener todos los pagos
    public List<Pago> getAllPagos() {
        return pagoRepository.findAll();
    }
}
