package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "Cliente")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    
    @Column(name="nombre_cliente")
    private String nombreCliente;
    
    @Column(name="rut")
    private String rut;
    
    

    public Cliente() {
		super();
	}

	public Cliente(int id, String nombreCliente, String rut) {
		super();
		this.id = id;
		this.nombreCliente = nombreCliente;
		this.rut = rut;
	}

	// Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }
}
