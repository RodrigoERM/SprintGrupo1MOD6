package cl.Grupo1.M6Sprint.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ContactoController {

    private static final Logger logger = Logger.getLogger(ContactoController.class);

    /**
     * Maneja las solicitudes GET a /contacto para mostrar el formulario de contacto
     * 
     * @return un objeto {@link ModelAndView} con la respuesta al cliente
     */
    @RequestMapping(path = "/contacto", method = RequestMethod.GET)
    public ModelAndView mostrarContacto() {
        return new ModelAndView("contacto");
    }

    /**
     * Procesa el formulario de contacto y muestra los datos en la consola
     * 
     * @param nombre El nombre del usuario
     * @param email El email del usuario
     * @param mensaje El mensaje del usuario
     * @return Un redireccionamiento a la página de contacto
     */
    @RequestMapping(path = "/contacto/enviar", method = RequestMethod.POST)
    public ModelAndView procesarContacto(@RequestParam("nombre") String nombre,
                                         @RequestParam("correo") String email,
                                         @RequestParam("consulta") String mensaje) {
        // Mostrar los datos en la consola usando Log4j
        logger.info("Nombre: " + nombre);
        logger.info("Correo: " + email);
        logger.info("Consulta: " + mensaje);

        // Redireccionar a la página de contacto
        return new ModelAndView("redirect:/contacto");
    }
}
