package cl.Grupo1.M6Sprint.controller;

import cl.Grupo1.M6Sprint.model.entity.Visitas;
import cl.Grupo1.M6Sprint.model.service.VisitasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class VisitasController {

    @Autowired
    private VisitasService visitaService;

    // Método para listar todas las visitas
    @GetMapping("/listarVisitas")
    public String listarVisitas(Model model) {
        List<Visitas> visitas = visitaService.getAllVisitas();
        model.addAttribute("visitas", visitas);
        model.addAttribute("visita", new Visitas()); // Para el formulario de nueva visita
        return "listarVisitas"; // Nombre del JSP para la lista de visitas
    }

    // Método para crear una nueva visita
    @PostMapping("/crearVisita")
    public String crearVisita(@ModelAttribute("visita") Visitas visita) {
        visitaService.createVisita(visita);
        return "redirect:/listarVisitas"; // Redirigir a la lista de visitas
    }

    // Método para eliminar una visita
    @GetMapping("/eliminar")
    public String eliminarVisita(@RequestParam("id") int id) {
        visitaService.deleteVisita(id);
        return "redirect:/listarVisitas"; // Redirigir a la lista de visitas
    }
}
