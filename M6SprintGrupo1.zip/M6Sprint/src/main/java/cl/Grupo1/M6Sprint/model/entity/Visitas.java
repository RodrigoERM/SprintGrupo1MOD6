package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "visitas")
public class Visitas {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    
    @Column(name="nombre")
    private String nombreVisita;
    
    @Column(name="detalle")
    private String detalle;

	public Visitas() {
		super();
	}

	public Visitas(int id, String nombreVisita, String detalle) {
		super();
		this.id = id;
		this.nombreVisita = nombreVisita;
		this.detalle = detalle;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombreVisita() {
		return nombreVisita;
	}

	public void setNombreVisita(String nombreVisita) {
		this.nombreVisita = nombreVisita;
	}

	public String getDetalle() {
		return detalle;
	}

	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}
    
    

}
