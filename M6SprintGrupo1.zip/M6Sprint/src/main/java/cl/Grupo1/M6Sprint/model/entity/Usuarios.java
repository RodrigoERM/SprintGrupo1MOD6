package cl.Grupo1.M6Sprint.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 
 * @version 1.0 (04-10-2024)
 *  
 * @author Rodrigo Rojas y Joeshep Lopez.
 */

/**
 * Representa la entidad "Usuarios" en la base de datos.
 * Mapea la tabla "usuarios" y contiene la información básica de un usuario.
 * Cada usuario tiene un ID, nombre, correo electrónico y tipo de usuario.
 */
@Entity
@Table(name = "usuarios")
public class Usuarios {

	/**
     * ID único del usuario.
     * Corresponde a la columna "id" de la tabla "usuarios".
     */
    @Id
    @Column(name = "id")
    private int id;

    /**
     * Nombre del usuario.
     * Corresponde a la columna "nombre" de la tabla "usuarios".
     */
    @Column(name="nombre")
    private String nombre;
    
    /**
     * Correo electrónico del usuario.
     * Corresponde a la columna "correo" de la tabla "usuarios".
     */
    @Column(name="correo")
    private String correo;
    
    /**
     * Tipo de usuario (e.g., "cliente", "administrativo" o "profesional").
     * Corresponde a la columna "tipo_usuario" de la tabla "usuarios".
     */
    @Column(name = "tipo_usuario")
    private String tipoUsuario;

    // Constructor por defecto
    public Usuarios() {
        super();
    }

    // Constructor con parámetros
    public Usuarios(int id, String nombre, String correo, String tipoUsuario) {
        super();
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.tipoUsuario = tipoUsuario;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    @Override
    public String toString() {
        return "Usuarios [id=" + id + ", nombre=" + nombre + ", correo=" + correo + ", tipoUsuario=" + tipoUsuario + "]";
    }
}
