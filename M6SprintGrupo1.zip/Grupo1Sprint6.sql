-- Crea la base de datos
CREATE DATABASE IF NOT EXISTS sprint6grupo1;

-- Usa la base de datos creada
USE sprint6grupo1;

-- Tabla "Usuarios"
CREATE TABLE IF NOT EXISTS usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  correo VARCHAR(100) NOT NULL UNIQUE,
  tipo_usuario ENUM('cliente', 'administrativo', 'profesional') NOT NULL
);

INSERT INTO usuarios (nombre, correo, tipo_usuario) VALUE ('Maria Muñoz', 'mariamuñoz@correo.cl', 'cliente');
INSERT INTO usuarios (nombre, correo, tipo_usuario) VALUE ('Felipe Torres', 'felipetorres@correo.cl', 'administrativo');
INSERT INTO usuarios (nombre, correo, tipo_usuario) VALUE ('Hugo Lopez', 'hugolopez@correo.cl', 'profesional');

-- Tabla "Cliente"
CREATE TABLE Cliente (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre_cliente VARCHAR(100) NOT NULL,
  rut VARCHAR(100) NOT NULL,
  FOREIGN KEY (id) REFERENCES usuarios(id) ON DELETE CASCADE
);

INSERT INTO Cliente (nombre_cliente, rut) VALUE ('Maria Muñoz', '1874545-7');

-- Tabla "Administrativo"
CREATE TABLE administrativo (
  id INT PRIMARY KEY AUTO_INCREMENT,
  funcion VARCHAR(100) NOT NULL,
  nombre_superior VARCHAR(100) NOT NULL,
  FOREIGN KEY (id) REFERENCES usuarios(id) ON DELETE CASCADE
);

INSERT INTO administrativo (funcion, nombre_superior) VALUE ('Gerencia', 'Cristobal Castro');

-- Tabla "Profesional"
CREATE TABLE profesional (
  id INT PRIMARY KEY AUTO_INCREMENT,
  años_experiencia INT NOT NULL,
  departamento VARCHAR(100) NOT NULL,
  FOREIGN KEY (id) REFERENCES usuarios(id) ON DELETE CASCADE
);

INSERT INTO profesional (años_experiencia, departamento) VALUE ('10', 'Ventas');

-- Tabla "Capacitaciones"
CREATE TABLE IF NOT EXISTS Capacitaciones (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  detalle TEXT,
  valor INT NOT NULL
);

INSERT INTO Capacitaciones (nombre, detalle) VALUE ('nombre ejemplo', 'detalle ejemplo');

-- Tabla "Visitas"
CREATE TABLE IF NOT EXISTS Visitas (
id INT PRIMARY KEY AUTO_INCREMENT,
nombre VARCHAR(100) NOT NULL,
detalle TEXT
);

INSERT INTO Visitas (nombre, detalle) VALUE ('nombre ejemplo', 'detalle ejemplo');

-- Tabla "Pago"
CREATE TABLE Pago (
    id INT AUTO_INCREMENT PRIMARY KEY,
    monto_cobro DECIMAL(10, 2) NOT NULL,
    monto_pagado DECIMAL(10, 2) NOT NULL,
    fecha_pago DATE NOT NULL,
    estado VARCHAR(20) -- "Pendiente", "Pagado"
);

INSERT INTO Pago (monto_cobro, monto_pagado, fecha_pago, estado) VALUE ('100000', '100000', '2024-10-04', 'Pagado');
INSERT INTO Pago (monto_cobro, monto_pagado, fecha_pago, estado) VALUE ('150000', '50000', '2024-09-15', 'Pendiente');

