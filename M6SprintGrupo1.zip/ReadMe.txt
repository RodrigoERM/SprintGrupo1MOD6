Roles Creados:

1. cliente:
	- Usuario: "usuarioC".
	- contraseña: "1234".
	- acceso: "Contacto", "Crear Capacitacion" y "Listado de Capacitaciones".

2. administrativo
	- Usuario: "usuarioA".
	- contraseña: "1234".
	- acceso: "Crear Usuario" y "Listado de Usuarios".

3. profesional:
	- Usuario_ "usuarioP"
	- contraseña: "1234"
	- acceso: "Listado Visitas"